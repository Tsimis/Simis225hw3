public class Patient{
    //creating variables
    public int IDNum;
    public double caffine;
    public boolean inArray=false;
    //constructor for patient
    public Patient(int IDNum, double caffine){
        this.IDNum=IDNum;
        this.caffine=caffine;
    }
    
}