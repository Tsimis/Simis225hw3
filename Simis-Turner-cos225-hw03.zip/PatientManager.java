public class PatientManager {
    public Patient[] PatientArray;

    public PatientManager(){
        PatientArray= new Patient[10];
        for ( int i =0; i < 10;i++){
            this.PatientArray[i]= new Patient(-1,-1);
            this.PatientArray[i].inArray=false;
        }
    }

    public int addPatient(Patient pat){
        for (int i = 0; i < 10;i++){
            if (this.PatientArray[i].inArray==false){
                this.PatientArray[i]=pat;
                this.PatientArray[i].inArray=true;
                return i;
            }
        }
        return -1;
    }
    
    public int removePatient(int index){
        this.PatientArray[index].inArray=false;
        return 0;
    }

    public int caffineAbsorbtion(){
        for (int i = 0; i < 10;i++){
            this.PatientArray[i].caffine=this.PatientArray[i].caffine-130;
            if (this.PatientArray[i].caffine<=0){
                removePatient(i);
            }
        }
        return 0;
    }

    public String toString(){
        int emptyCount=0;
        for (int i = 0; i < 10;i++){
            if (this.PatientArray[i].inArray==false){
                emptyCount++;
                if (emptyCount==10){
                    String empty="Empty";
                    return empty;
                }
            }
            if (this.PatientArray[i].inArray==true){
                System.out.println(this.PatientArray[i].IDNum+" "+this.PatientArray[i].caffine);
            }
        }
        return "";
    }
}
