public class PatientTester {
    public static void main(String[] args){
        PatientManager patientManager= new PatientManager();
        System.out.println(patientManager.toString());
        Patient pat1 = new Patient(1,200);
        Patient pat2 = new Patient(2,400);
        Patient pat3 = new Patient(3,600);
        Patient pat4 = new Patient(4,800);
        patientManager.addPatient(pat1);
        patientManager.addPatient(pat2);
        patientManager.addPatient(pat3);
        patientManager.addPatient(pat4);
        System.out.println(patientManager.toString());
        patientManager.caffineAbsorbtion();
        patientManager.caffineAbsorbtion();
        System.out.println(patientManager.toString());
        patientManager.removePatient(3);
        System.out.println(patientManager.toString());
    }
}
